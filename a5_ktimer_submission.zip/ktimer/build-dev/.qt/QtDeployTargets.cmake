set(__QT_DEPLOY_TARGET_ktimer_FILE /home/zreynolds/kde/src/ktimer/build-dev/bin/ktimer)
set(__QT_DEPLOY_TARGET_ktimer_TYPE EXECUTABLE)
