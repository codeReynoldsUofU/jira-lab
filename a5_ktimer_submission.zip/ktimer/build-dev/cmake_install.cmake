# Install script for directory: /home/zreynolds/kde/src/ktimer

# Set the install prefix
if(NOT DEFINED CMAKE_INSTALL_PREFIX)
  set(CMAKE_INSTALL_PREFIX "")
endif()
string(REGEX REPLACE "/$" "" CMAKE_INSTALL_PREFIX "${CMAKE_INSTALL_PREFIX}")

# Set the install configuration name.
if(NOT DEFINED CMAKE_INSTALL_CONFIG_NAME)
  if(BUILD_TYPE)
    string(REGEX REPLACE "^[^A-Za-z0-9_]+" ""
           CMAKE_INSTALL_CONFIG_NAME "${BUILD_TYPE}")
  else()
    set(CMAKE_INSTALL_CONFIG_NAME "Debug")
  endif()
  message(STATUS "Install configuration: \"${CMAKE_INSTALL_CONFIG_NAME}\"")
endif()

# Set the component getting installed.
if(NOT CMAKE_INSTALL_COMPONENT)
  if(COMPONENT)
    message(STATUS "Install component: \"${COMPONENT}\"")
    set(CMAKE_INSTALL_COMPONENT "${COMPONENT}")
  else()
    set(CMAKE_INSTALL_COMPONENT)
  endif()
endif()

# Install shared libraries without execute permission?
if(NOT DEFINED CMAKE_INSTALL_SO_NO_EXE)
  set(CMAKE_INSTALL_SO_NO_EXE "0")
endif()

# Is this installation the result of a crosscompile?
if(NOT DEFINED CMAKE_CROSSCOMPILING)
  set(CMAKE_CROSSCOMPILING "FALSE")
endif()

# Set path to fallback-tool for dependency-resolution.
if(NOT DEFINED CMAKE_OBJDUMP)
  set(CMAKE_OBJDUMP "/usr/bin/objdump")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "ktimer" OR NOT CMAKE_INSTALL_COMPONENT)
  if(EXISTS "$ENV{DESTDIR}${CMAKE_INSTALL_PREFIX}/bin/ktimer" AND
     NOT IS_SYMLINK "$ENV{DESTDIR}${CMAKE_INSTALL_PREFIX}/bin/ktimer")
    file(RPATH_CHECK
         FILE "$ENV{DESTDIR}${CMAKE_INSTALL_PREFIX}/bin/ktimer"
         RPATH "/home/zreynolds/kde/usr/lib64")
  endif()
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/bin" TYPE EXECUTABLE FILES "/home/zreynolds/kde/src/ktimer/build-dev/bin/ktimer")
  if(EXISTS "$ENV{DESTDIR}${CMAKE_INSTALL_PREFIX}/bin/ktimer" AND
     NOT IS_SYMLINK "$ENV{DESTDIR}${CMAKE_INSTALL_PREFIX}/bin/ktimer")
    file(RPATH_CHANGE
         FILE "$ENV{DESTDIR}${CMAKE_INSTALL_PREFIX}/bin/ktimer"
         OLD_RPATH "/home/zreynolds/kde/usr/lib64:"
         NEW_RPATH "/home/zreynolds/kde/usr/lib64")
    if(CMAKE_INSTALL_DO_STRIP)
      execute_process(COMMAND "/usr/bin/strip" "$ENV{DESTDIR}${CMAKE_INSTALL_PREFIX}/bin/ktimer")
    endif()
  endif()
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "ktimer" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/applications" TYPE PROGRAM FILES "/home/zreynolds/kde/src/ktimer/org.kde.ktimer.desktop")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "ktimer" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/metainfo" TYPE FILE FILES "/home/zreynolds/kde/src/ktimer/org.kde.ktimer.appdata.xml")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "ktimer" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/icons/hicolor/128x128/apps" TYPE FILE RENAME "ktimer.png" FILES "/home/zreynolds/kde/src/ktimer/128-apps-ktimer.png")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "ktimer" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/icons/hicolor/16x16/apps" TYPE FILE RENAME "ktimer.png" FILES "/home/zreynolds/kde/src/ktimer/16-apps-ktimer.png")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "ktimer" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/icons/hicolor/32x32/apps" TYPE FILE RENAME "ktimer.png" FILES "/home/zreynolds/kde/src/ktimer/32-apps-ktimer.png")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "ktimer" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/icons/hicolor/48x48/apps" TYPE FILE RENAME "ktimer.png" FILES "/home/zreynolds/kde/src/ktimer/48-apps-ktimer.png")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "ktimer" OR NOT CMAKE_INSTALL_COMPONENT)
  
    set(DESTDIR_VALUE "$ENV{DESTDIR}")
    if (NOT DESTDIR_VALUE)
        execute_process(COMMAND "/usr/bin/cmake" -E touch "/share/icons/hicolor")
        set(HAVE_GTK_UPDATE_ICON_CACHE_EXEC /usr/bin/gtk-update-icon-cache)
        if (HAVE_GTK_UPDATE_ICON_CACHE_EXEC)
            execute_process(COMMAND /usr/bin/gtk-update-icon-cache -q -t -i . WORKING_DIRECTORY "/share/icons/hicolor")
        endif ()
    endif (NOT DESTDIR_VALUE)
    
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "ktimer" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/doc/HTML/ca/ktimer" TYPE FILE FILES
    "/home/zreynolds/kde/src/ktimer/build-dev/po/ca/docs/ktimer/index.cache.bz2"
    "/home/zreynolds/kde/src/ktimer/po/ca/docs/ktimer/index.docbook"
    )
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "ktimer" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/doc/HTML/cs/ktimer" TYPE FILE FILES
    "/home/zreynolds/kde/src/ktimer/build-dev/po/cs/docs/ktimer/index.cache.bz2"
    "/home/zreynolds/kde/src/ktimer/po/cs/docs/ktimer/index.docbook"
    )
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "ktimer" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/doc/HTML/de/ktimer" TYPE FILE FILES
    "/home/zreynolds/kde/src/ktimer/build-dev/po/de/docs/ktimer/index.cache.bz2"
    "/home/zreynolds/kde/src/ktimer/po/de/docs/ktimer/index.docbook"
    "/home/zreynolds/kde/src/ktimer/po/de/docs/ktimer/first.png"
    "/home/zreynolds/kde/src/ktimer/po/de/docs/ktimer/main.png"
    "/home/zreynolds/kde/src/ktimer/po/de/docs/ktimer/running.png"
    "/home/zreynolds/kde/src/ktimer/po/de/docs/ktimer/two_at_once.png"
    )
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "ktimer" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/doc/HTML/es/ktimer" TYPE FILE FILES
    "/home/zreynolds/kde/src/ktimer/build-dev/po/es/docs/ktimer/index.cache.bz2"
    "/home/zreynolds/kde/src/ktimer/po/es/docs/ktimer/index.docbook"
    )
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "ktimer" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/doc/HTML/et/ktimer" TYPE FILE FILES
    "/home/zreynolds/kde/src/ktimer/build-dev/po/et/docs/ktimer/index.cache.bz2"
    "/home/zreynolds/kde/src/ktimer/po/et/docs/ktimer/index.docbook"
    )
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "ktimer" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/doc/HTML/fr/ktimer" TYPE FILE FILES
    "/home/zreynolds/kde/src/ktimer/build-dev/po/fr/docs/ktimer/index.cache.bz2"
    "/home/zreynolds/kde/src/ktimer/po/fr/docs/ktimer/index.docbook"
    )
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "ktimer" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/doc/HTML/it/ktimer" TYPE FILE FILES
    "/home/zreynolds/kde/src/ktimer/build-dev/po/it/docs/ktimer/index.cache.bz2"
    "/home/zreynolds/kde/src/ktimer/po/it/docs/ktimer/index.docbook"
    )
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "ktimer" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/doc/HTML/nl/ktimer" TYPE FILE FILES
    "/home/zreynolds/kde/src/ktimer/build-dev/po/nl/docs/ktimer/index.cache.bz2"
    "/home/zreynolds/kde/src/ktimer/po/nl/docs/ktimer/index.docbook"
    )
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "ktimer" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/doc/HTML/pt/ktimer" TYPE FILE FILES
    "/home/zreynolds/kde/src/ktimer/build-dev/po/pt/docs/ktimer/index.cache.bz2"
    "/home/zreynolds/kde/src/ktimer/po/pt/docs/ktimer/index.docbook"
    )
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "ktimer" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/doc/HTML/pt_BR/ktimer" TYPE FILE FILES
    "/home/zreynolds/kde/src/ktimer/build-dev/po/pt_BR/docs/ktimer/index.cache.bz2"
    "/home/zreynolds/kde/src/ktimer/po/pt_BR/docs/ktimer/index.docbook"
    "/home/zreynolds/kde/src/ktimer/po/pt_BR/docs/ktimer/first.png"
    "/home/zreynolds/kde/src/ktimer/po/pt_BR/docs/ktimer/main.png"
    "/home/zreynolds/kde/src/ktimer/po/pt_BR/docs/ktimer/running.png"
    "/home/zreynolds/kde/src/ktimer/po/pt_BR/docs/ktimer/two_at_once.png"
    )
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "ktimer" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/doc/HTML/ru/ktimer" TYPE FILE FILES
    "/home/zreynolds/kde/src/ktimer/build-dev/po/ru/docs/ktimer/index.cache.bz2"
    "/home/zreynolds/kde/src/ktimer/po/ru/docs/ktimer/index.docbook"
    )
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "ktimer" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/doc/HTML/sl/ktimer" TYPE FILE FILES
    "/home/zreynolds/kde/src/ktimer/build-dev/po/sl/docs/ktimer/index.cache.bz2"
    "/home/zreynolds/kde/src/ktimer/po/sl/docs/ktimer/index.docbook"
    )
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "ktimer" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/doc/HTML/sr/ktimer" TYPE FILE FILES
    "/home/zreynolds/kde/src/ktimer/build-dev/po/sr/docs/ktimer/index.cache.bz2"
    "/home/zreynolds/kde/src/ktimer/po/sr/docs/ktimer/index.docbook"
    )
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "ktimer" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/doc/HTML/sr@latin/ktimer" TYPE FILE FILES
    "/home/zreynolds/kde/src/ktimer/build-dev/po/sr@latin/docs/ktimer/index.cache.bz2"
    "/home/zreynolds/kde/src/ktimer/po/sr@latin/docs/ktimer/index.docbook"
    )
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "ktimer" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/doc/HTML/sv/ktimer" TYPE FILE FILES
    "/home/zreynolds/kde/src/ktimer/build-dev/po/sv/docs/ktimer/index.cache.bz2"
    "/home/zreynolds/kde/src/ktimer/po/sv/docs/ktimer/index.docbook"
    )
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "ktimer" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/doc/HTML/tr/ktimer" TYPE FILE FILES
    "/home/zreynolds/kde/src/ktimer/build-dev/po/tr/docs/ktimer/index.cache.bz2"
    "/home/zreynolds/kde/src/ktimer/po/tr/docs/ktimer/index.docbook"
    "/home/zreynolds/kde/src/ktimer/po/tr/docs/ktimer/first.png"
    "/home/zreynolds/kde/src/ktimer/po/tr/docs/ktimer/main.png"
    "/home/zreynolds/kde/src/ktimer/po/tr/docs/ktimer/running.png"
    "/home/zreynolds/kde/src/ktimer/po/tr/docs/ktimer/two_at_once.png"
    )
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "ktimer" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/doc/HTML/uk/ktimer" TYPE FILE FILES
    "/home/zreynolds/kde/src/ktimer/build-dev/po/uk/docs/ktimer/index.cache.bz2"
    "/home/zreynolds/kde/src/ktimer/po/uk/docs/ktimer/index.docbook"
    "/home/zreynolds/kde/src/ktimer/po/uk/docs/ktimer/first.png"
    "/home/zreynolds/kde/src/ktimer/po/uk/docs/ktimer/main.png"
    "/home/zreynolds/kde/src/ktimer/po/uk/docs/ktimer/running.png"
    "/home/zreynolds/kde/src/ktimer/po/uk/docs/ktimer/two_at_once.png"
    )
endif()

if(NOT CMAKE_INSTALL_LOCAL_ONLY)
  # Include the install script for the subdirectory.
  include("/home/zreynolds/kde/src/ktimer/build-dev/doc/cmake_install.cmake")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "ktimer" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share" TYPE DIRECTORY FILES "/home/zreynolds/kde/src/ktimer/build-dev/locale")
endif()

string(REPLACE ";" "\n" CMAKE_INSTALL_MANIFEST_CONTENT
       "${CMAKE_INSTALL_MANIFEST_FILES}")
if(CMAKE_INSTALL_LOCAL_ONLY)
  file(WRITE "/home/zreynolds/kde/src/ktimer/build-dev/install_local_manifest.txt"
     "${CMAKE_INSTALL_MANIFEST_CONTENT}")
endif()
if(CMAKE_INSTALL_COMPONENT)
  if(CMAKE_INSTALL_COMPONENT MATCHES "^[a-zA-Z0-9_.+-]+$")
    set(CMAKE_INSTALL_MANIFEST "install_manifest_${CMAKE_INSTALL_COMPONENT}.txt")
  else()
    string(MD5 CMAKE_INST_COMP_HASH "${CMAKE_INSTALL_COMPONENT}")
    set(CMAKE_INSTALL_MANIFEST "install_manifest_${CMAKE_INST_COMP_HASH}.txt")
    unset(CMAKE_INST_COMP_HASH)
  endif()
else()
  set(CMAKE_INSTALL_MANIFEST "install_manifest.txt")
endif()

if(NOT CMAKE_INSTALL_LOCAL_ONLY)
  file(WRITE "/home/zreynolds/kde/src/ktimer/build-dev/${CMAKE_INSTALL_MANIFEST}"
     "${CMAKE_INSTALL_MANIFEST_CONTENT}")
endif()
