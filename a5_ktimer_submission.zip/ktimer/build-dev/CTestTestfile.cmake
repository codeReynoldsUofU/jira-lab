# CMake generated Testfile for 
# Source directory: /home/zreynolds/kde/src/ktimer
# Build directory: /home/zreynolds/kde/src/ktimer/build-dev
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
add_test(appstreamtest "/usr/bin/cmake" "-DAPPSTREAMCLI=/usr/bin/appstreamcli" "-DINSTALL_FILES=/home/zreynolds/kde/src/ktimer/build-dev/install_manifest.txt" "-P" "/home/zreynolds/kde/usr/share/ECM/kde-modules/appstreamtest.cmake")
set_tests_properties(appstreamtest PROPERTIES  _BACKTRACE_TRIPLES "/home/zreynolds/kde/usr/share/ECM/kde-modules/KDECMakeSettings.cmake;177;add_test;/home/zreynolds/kde/usr/share/ECM/kde-modules/KDECMakeSettings.cmake;195;appstreamtest;/home/zreynolds/kde/usr/share/ECM/kde-modules/KDECMakeSettings.cmake;0;;/home/zreynolds/kde/src/ktimer/CMakeLists.txt;16;include;/home/zreynolds/kde/src/ktimer/CMakeLists.txt;0;")
subdirs("doc")
