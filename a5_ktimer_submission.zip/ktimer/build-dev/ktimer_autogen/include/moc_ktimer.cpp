/****************************************************************************
** Meta object code from reading C++ file 'ktimer.h'
**
** Created by: The Qt Meta Object Compiler version 69 (Qt 6.11.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../../ktimer.h"
#include <QtGui/qtextcursor.h>
#include <QtCore/qmetatype.h>

#include <QtCore/qtmochelpers.h>

#include <memory>


#include <QtCore/qxptype_traits.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'ktimer.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 69
#error "This file was generated using the moc from 6.11.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
QT_WARNING_DISABLE_GCC("-Wuseless-cast")
namespace {
struct qt_meta_tag_ZN9KTimerJobE_t {};
} // unnamed namespace

template <> constexpr inline auto KTimerJob::qt_create_metaobjectdata<qt_meta_tag_ZN9KTimerJobE_t>()
{
    namespace QMC = QtMocConstants;
    QtMocHelpers::StringRefStorage qt_stringData {
        "KTimerJob",
        "stateChanged",
        "",
        "KTimerJob*",
        "job",
        "KTimerJob::States",
        "state",
        "delayChanged",
        "sec",
        "commandChanged",
        "cmd",
        "loopChanged",
        "loop",
        "oneInstanceChanged",
        "one",
        "consecutiveChanged",
        "consecutive",
        "valueChanged",
        "value",
        "changed",
        "fired",
        "finished",
        "error",
        "setDelay",
        "setCommand",
        "setLoop",
        "setOneInstance",
        "setConsecutive",
        "setValue",
        "setState",
        "setLastRun",
        "time",
        "pause",
        "stop",
        "start",
        "fire",
        "timeout",
        "processExited",
        "QProcess::ExitStatus"
    };

    QtMocHelpers::UintData qt_methods {
        // Signal 'stateChanged'
        QtMocHelpers::SignalData<void(KTimerJob *, KTimerJob::States)>(1, 2, QMC::AccessPublic, QMetaType::Void, {{
            { 0x80000000 | 3, 4 }, { 0x80000000 | 5, 6 },
        }}),
        // Signal 'delayChanged'
        QtMocHelpers::SignalData<void(KTimerJob *, unsigned int)>(7, 2, QMC::AccessPublic, QMetaType::Void, {{
            { 0x80000000 | 3, 4 }, { QMetaType::UInt, 8 },
        }}),
        // Signal 'commandChanged'
        QtMocHelpers::SignalData<void(KTimerJob *, const QString &)>(9, 2, QMC::AccessPublic, QMetaType::Void, {{
            { 0x80000000 | 3, 4 }, { QMetaType::QString, 10 },
        }}),
        // Signal 'loopChanged'
        QtMocHelpers::SignalData<void(KTimerJob *, bool)>(11, 2, QMC::AccessPublic, QMetaType::Void, {{
            { 0x80000000 | 3, 4 }, { QMetaType::Bool, 12 },
        }}),
        // Signal 'oneInstanceChanged'
        QtMocHelpers::SignalData<void(KTimerJob *, bool)>(13, 2, QMC::AccessPublic, QMetaType::Void, {{
            { 0x80000000 | 3, 4 }, { QMetaType::Bool, 14 },
        }}),
        // Signal 'consecutiveChanged'
        QtMocHelpers::SignalData<void(KTimerJob *, bool)>(15, 2, QMC::AccessPublic, QMetaType::Void, {{
            { 0x80000000 | 3, 4 }, { QMetaType::Bool, 16 },
        }}),
        // Signal 'valueChanged'
        QtMocHelpers::SignalData<void(KTimerJob *, unsigned int)>(17, 2, QMC::AccessPublic, QMetaType::Void, {{
            { 0x80000000 | 3, 4 }, { QMetaType::UInt, 18 },
        }}),
        // Signal 'changed'
        QtMocHelpers::SignalData<void(KTimerJob *)>(19, 2, QMC::AccessPublic, QMetaType::Void, {{
            { 0x80000000 | 3, 4 },
        }}),
        // Signal 'fired'
        QtMocHelpers::SignalData<void(KTimerJob *)>(20, 2, QMC::AccessPublic, QMetaType::Void, {{
            { 0x80000000 | 3, 4 },
        }}),
        // Signal 'finished'
        QtMocHelpers::SignalData<void(KTimerJob *, bool)>(21, 2, QMC::AccessPublic, QMetaType::Void, {{
            { 0x80000000 | 3, 4 }, { QMetaType::Bool, 22 },
        }}),
        // Signal 'error'
        QtMocHelpers::SignalData<void(KTimerJob *)>(22, 2, QMC::AccessPublic, QMetaType::Void, {{
            { 0x80000000 | 3, 4 },
        }}),
        // Slot 'setDelay'
        QtMocHelpers::SlotData<void(unsigned int)>(23, 2, QMC::AccessPublic, QMetaType::Void, {{
            { QMetaType::UInt, 8 },
        }}),
        // Slot 'setDelay'
        QtMocHelpers::SlotData<void(int)>(23, 2, QMC::AccessPublic, QMetaType::Void, {{
            { QMetaType::Int, 8 },
        }}),
        // Slot 'setCommand'
        QtMocHelpers::SlotData<void(const QString &)>(24, 2, QMC::AccessPublic, QMetaType::Void, {{
            { QMetaType::QString, 10 },
        }}),
        // Slot 'setLoop'
        QtMocHelpers::SlotData<void(bool)>(25, 2, QMC::AccessPublic, QMetaType::Void, {{
            { QMetaType::Bool, 12 },
        }}),
        // Slot 'setOneInstance'
        QtMocHelpers::SlotData<void(bool)>(26, 2, QMC::AccessPublic, QMetaType::Void, {{
            { QMetaType::Bool, 14 },
        }}),
        // Slot 'setConsecutive'
        QtMocHelpers::SlotData<void(bool)>(27, 2, QMC::AccessPublic, QMetaType::Void, {{
            { QMetaType::Bool, 16 },
        }}),
        // Slot 'setValue'
        QtMocHelpers::SlotData<void(unsigned int)>(28, 2, QMC::AccessPublic, QMetaType::Void, {{
            { QMetaType::UInt, 18 },
        }}),
        // Slot 'setValue'
        QtMocHelpers::SlotData<void(int)>(28, 2, QMC::AccessPublic, QMetaType::Void, {{
            { QMetaType::Int, 18 },
        }}),
        // Slot 'setState'
        QtMocHelpers::SlotData<void(KTimerJob::States)>(29, 2, QMC::AccessPublic, QMetaType::Void, {{
            { 0x80000000 | 5, 6 },
        }}),
        // Slot 'setLastRun'
        QtMocHelpers::SlotData<void(const QDateTime &)>(30, 2, QMC::AccessPublic, QMetaType::Void, {{
            { QMetaType::QDateTime, 31 },
        }}),
        // Slot 'pause'
        QtMocHelpers::SlotData<void()>(32, 2, QMC::AccessPublic, QMetaType::Void),
        // Slot 'stop'
        QtMocHelpers::SlotData<void()>(33, 2, QMC::AccessPublic, QMetaType::Void),
        // Slot 'start'
        QtMocHelpers::SlotData<void()>(34, 2, QMC::AccessPublic, QMetaType::Void),
        // Slot 'fire'
        QtMocHelpers::SlotData<void()>(35, 2, QMC::AccessProtected, QMetaType::Void),
        // Slot 'timeout'
        QtMocHelpers::SlotData<void()>(36, 2, QMC::AccessPrivate, QMetaType::Void),
        // Slot 'processExited'
        QtMocHelpers::SlotData<void(int, QProcess::ExitStatus)>(37, 2, QMC::AccessPrivate, QMetaType::Void, {{
            { QMetaType::Int, 2 }, { 0x80000000 | 38, 2 },
        }}),
    };
    QtMocHelpers::UintData qt_properties {
    };
    QtMocHelpers::UintData qt_enums {
    };
    return QtMocHelpers::metaObjectData<KTimerJob, qt_meta_tag_ZN9KTimerJobE_t>(QMC::MetaObjectFlag{}, qt_stringData,
            qt_methods, qt_properties, qt_enums);
}
Q_CONSTINIT const QMetaObject KTimerJob::staticMetaObject = { {
    QMetaObject::SuperData::link<QObject::staticMetaObject>(),
    qt_staticMetaObjectStaticContent<qt_meta_tag_ZN9KTimerJobE_t>.stringdata,
    qt_staticMetaObjectStaticContent<qt_meta_tag_ZN9KTimerJobE_t>.data,
    qt_static_metacall,
    nullptr,
    qt_staticMetaObjectRelocatingContent<qt_meta_tag_ZN9KTimerJobE_t>.metaTypes,
    nullptr
} };

void KTimerJob::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    auto *_t = static_cast<KTimerJob *>(_o);
    if (_c == QMetaObject::InvokeMetaMethod) {
        switch (_id) {
        case 0: _t->stateChanged((*reinterpret_cast<std::add_pointer_t<KTimerJob*>>(_a[1])),(*reinterpret_cast<std::add_pointer_t<KTimerJob::States>>(_a[2]))); break;
        case 1: _t->delayChanged((*reinterpret_cast<std::add_pointer_t<KTimerJob*>>(_a[1])),(*reinterpret_cast<std::add_pointer_t<uint>>(_a[2]))); break;
        case 2: _t->commandChanged((*reinterpret_cast<std::add_pointer_t<KTimerJob*>>(_a[1])),(*reinterpret_cast<std::add_pointer_t<QString>>(_a[2]))); break;
        case 3: _t->loopChanged((*reinterpret_cast<std::add_pointer_t<KTimerJob*>>(_a[1])),(*reinterpret_cast<std::add_pointer_t<bool>>(_a[2]))); break;
        case 4: _t->oneInstanceChanged((*reinterpret_cast<std::add_pointer_t<KTimerJob*>>(_a[1])),(*reinterpret_cast<std::add_pointer_t<bool>>(_a[2]))); break;
        case 5: _t->consecutiveChanged((*reinterpret_cast<std::add_pointer_t<KTimerJob*>>(_a[1])),(*reinterpret_cast<std::add_pointer_t<bool>>(_a[2]))); break;
        case 6: _t->valueChanged((*reinterpret_cast<std::add_pointer_t<KTimerJob*>>(_a[1])),(*reinterpret_cast<std::add_pointer_t<uint>>(_a[2]))); break;
        case 7: _t->changed((*reinterpret_cast<std::add_pointer_t<KTimerJob*>>(_a[1]))); break;
        case 8: _t->fired((*reinterpret_cast<std::add_pointer_t<KTimerJob*>>(_a[1]))); break;
        case 9: _t->finished((*reinterpret_cast<std::add_pointer_t<KTimerJob*>>(_a[1])),(*reinterpret_cast<std::add_pointer_t<bool>>(_a[2]))); break;
        case 10: _t->error((*reinterpret_cast<std::add_pointer_t<KTimerJob*>>(_a[1]))); break;
        case 11: _t->setDelay((*reinterpret_cast<std::add_pointer_t<uint>>(_a[1]))); break;
        case 12: _t->setDelay((*reinterpret_cast<std::add_pointer_t<int>>(_a[1]))); break;
        case 13: _t->setCommand((*reinterpret_cast<std::add_pointer_t<QString>>(_a[1]))); break;
        case 14: _t->setLoop((*reinterpret_cast<std::add_pointer_t<bool>>(_a[1]))); break;
        case 15: _t->setOneInstance((*reinterpret_cast<std::add_pointer_t<bool>>(_a[1]))); break;
        case 16: _t->setConsecutive((*reinterpret_cast<std::add_pointer_t<bool>>(_a[1]))); break;
        case 17: _t->setValue((*reinterpret_cast<std::add_pointer_t<uint>>(_a[1]))); break;
        case 18: _t->setValue((*reinterpret_cast<std::add_pointer_t<int>>(_a[1]))); break;
        case 19: _t->setState((*reinterpret_cast<std::add_pointer_t<KTimerJob::States>>(_a[1]))); break;
        case 20: _t->setLastRun((*reinterpret_cast<std::add_pointer_t<QDateTime>>(_a[1]))); break;
        case 21: _t->pause(); break;
        case 22: _t->stop(); break;
        case 23: _t->start(); break;
        case 24: _t->fire(); break;
        case 25: _t->timeout(); break;
        case 26: _t->processExited((*reinterpret_cast<std::add_pointer_t<int>>(_a[1])),(*reinterpret_cast<std::add_pointer_t<QProcess::ExitStatus>>(_a[2]))); break;
        default: ;
        }
    }
    if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        switch (_id) {
        default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
        case 0:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 0:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< KTimerJob* >(); break;
            }
            break;
        case 1:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 0:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< KTimerJob* >(); break;
            }
            break;
        case 2:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 0:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< KTimerJob* >(); break;
            }
            break;
        case 3:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 0:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< KTimerJob* >(); break;
            }
            break;
        case 4:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 0:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< KTimerJob* >(); break;
            }
            break;
        case 5:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 0:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< KTimerJob* >(); break;
            }
            break;
        case 6:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 0:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< KTimerJob* >(); break;
            }
            break;
        case 7:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 0:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< KTimerJob* >(); break;
            }
            break;
        case 8:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 0:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< KTimerJob* >(); break;
            }
            break;
        case 9:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 0:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< KTimerJob* >(); break;
            }
            break;
        case 10:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 0:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< KTimerJob* >(); break;
            }
            break;
        }
    }
    if (_c == QMetaObject::IndexOfMethod) {
        if (QtMocHelpers::indexOfMethod<void (KTimerJob::*)(KTimerJob * , KTimerJob::States )>(_a, &KTimerJob::stateChanged, 0))
            return;
        if (QtMocHelpers::indexOfMethod<void (KTimerJob::*)(KTimerJob * , unsigned int )>(_a, &KTimerJob::delayChanged, 1))
            return;
        if (QtMocHelpers::indexOfMethod<void (KTimerJob::*)(KTimerJob * , const QString & )>(_a, &KTimerJob::commandChanged, 2))
            return;
        if (QtMocHelpers::indexOfMethod<void (KTimerJob::*)(KTimerJob * , bool )>(_a, &KTimerJob::loopChanged, 3))
            return;
        if (QtMocHelpers::indexOfMethod<void (KTimerJob::*)(KTimerJob * , bool )>(_a, &KTimerJob::oneInstanceChanged, 4))
            return;
        if (QtMocHelpers::indexOfMethod<void (KTimerJob::*)(KTimerJob * , bool )>(_a, &KTimerJob::consecutiveChanged, 5))
            return;
        if (QtMocHelpers::indexOfMethod<void (KTimerJob::*)(KTimerJob * , unsigned int )>(_a, &KTimerJob::valueChanged, 6))
            return;
        if (QtMocHelpers::indexOfMethod<void (KTimerJob::*)(KTimerJob * )>(_a, &KTimerJob::changed, 7))
            return;
        if (QtMocHelpers::indexOfMethod<void (KTimerJob::*)(KTimerJob * )>(_a, &KTimerJob::fired, 8))
            return;
        if (QtMocHelpers::indexOfMethod<void (KTimerJob::*)(KTimerJob * , bool )>(_a, &KTimerJob::finished, 9))
            return;
        if (QtMocHelpers::indexOfMethod<void (KTimerJob::*)(KTimerJob * )>(_a, &KTimerJob::error, 10))
            return;
    }
}

const QMetaObject *KTimerJob::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *KTimerJob::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_staticMetaObjectStaticContent<qt_meta_tag_ZN9KTimerJobE_t>.strings))
        return static_cast<void*>(this);
    return QObject::qt_metacast(_clname);
}

int KTimerJob::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 27)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 27;
    }
    if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 27)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 27;
    }
    return _id;
}

// SIGNAL 0
void KTimerJob::stateChanged(KTimerJob * _t1, KTimerJob::States _t2)
{
    QMetaObject::activate<void>(this, &staticMetaObject, 0, nullptr, _t1, _t2);
}

// SIGNAL 1
void KTimerJob::delayChanged(KTimerJob * _t1, unsigned int _t2)
{
    QMetaObject::activate<void>(this, &staticMetaObject, 1, nullptr, _t1, _t2);
}

// SIGNAL 2
void KTimerJob::commandChanged(KTimerJob * _t1, const QString & _t2)
{
    QMetaObject::activate<void>(this, &staticMetaObject, 2, nullptr, _t1, _t2);
}

// SIGNAL 3
void KTimerJob::loopChanged(KTimerJob * _t1, bool _t2)
{
    QMetaObject::activate<void>(this, &staticMetaObject, 3, nullptr, _t1, _t2);
}

// SIGNAL 4
void KTimerJob::oneInstanceChanged(KTimerJob * _t1, bool _t2)
{
    QMetaObject::activate<void>(this, &staticMetaObject, 4, nullptr, _t1, _t2);
}

// SIGNAL 5
void KTimerJob::consecutiveChanged(KTimerJob * _t1, bool _t2)
{
    QMetaObject::activate<void>(this, &staticMetaObject, 5, nullptr, _t1, _t2);
}

// SIGNAL 6
void KTimerJob::valueChanged(KTimerJob * _t1, unsigned int _t2)
{
    QMetaObject::activate<void>(this, &staticMetaObject, 6, nullptr, _t1, _t2);
}

// SIGNAL 7
void KTimerJob::changed(KTimerJob * _t1)
{
    QMetaObject::activate<void>(this, &staticMetaObject, 7, nullptr, _t1);
}

// SIGNAL 8
void KTimerJob::fired(KTimerJob * _t1)
{
    QMetaObject::activate<void>(this, &staticMetaObject, 8, nullptr, _t1);
}

// SIGNAL 9
void KTimerJob::finished(KTimerJob * _t1, bool _t2)
{
    QMetaObject::activate<void>(this, &staticMetaObject, 9, nullptr, _t1, _t2);
}

// SIGNAL 10
void KTimerJob::error(KTimerJob * _t1)
{
    QMetaObject::activate<void>(this, &staticMetaObject, 10, nullptr, _t1);
}
namespace {
struct qt_meta_tag_ZN10KTimerPrefE_t {};
} // unnamed namespace

template <> constexpr inline auto KTimerPref::qt_create_metaobjectdata<qt_meta_tag_ZN10KTimerPrefE_t>()
{
    namespace QMC = QtMocConstants;
    QtMocHelpers::StringRefStorage qt_stringData {
        "KTimerPref",
        "exit",
        "",
        "done",
        "result",
        "add",
        "remove",
        "help",
        "currentChanged",
        "QTreeWidgetItem*",
        "saveJobs",
        "KConfig*",
        "cfg",
        "loadJobs",
        "saveAllJobs",
        "jobChanged",
        "KTimerJob*",
        "job",
        "jobFinished",
        "error",
        "delayChanged"
    };

    QtMocHelpers::UintData qt_methods {
        // Slot 'exit'
        QtMocHelpers::SlotData<void()>(1, 2, QMC::AccessPublic, QMetaType::Void),
        // Slot 'done'
        QtMocHelpers::SlotData<void(int)>(3, 2, QMC::AccessPublic, QMetaType::Void, {{
            { QMetaType::Int, 4 },
        }}),
        // Slot 'add'
        QtMocHelpers::SlotData<void()>(5, 2, QMC::AccessProtected, QMetaType::Void),
        // Slot 'remove'
        QtMocHelpers::SlotData<void()>(6, 2, QMC::AccessProtected, QMetaType::Void),
        // Slot 'help'
        QtMocHelpers::SlotData<void()>(7, 2, QMC::AccessProtected, QMetaType::Void),
        // Slot 'currentChanged'
        QtMocHelpers::SlotData<void(QTreeWidgetItem *, QTreeWidgetItem *)>(8, 2, QMC::AccessProtected, QMetaType::Void, {{
            { 0x80000000 | 9, 2 }, { 0x80000000 | 9, 2 },
        }}),
        // Slot 'saveJobs'
        QtMocHelpers::SlotData<void(KConfig *)>(10, 2, QMC::AccessProtected, QMetaType::Void, {{
            { 0x80000000 | 11, 12 },
        }}),
        // Slot 'loadJobs'
        QtMocHelpers::SlotData<void(KConfig *)>(13, 2, QMC::AccessProtected, QMetaType::Void, {{
            { 0x80000000 | 11, 12 },
        }}),
        // Slot 'saveAllJobs'
        QtMocHelpers::SlotData<void()>(14, 2, QMC::AccessProtected, QMetaType::Void),
        // Slot 'jobChanged'
        QtMocHelpers::SlotData<void(KTimerJob *)>(15, 2, QMC::AccessPrivate, QMetaType::Void, {{
            { 0x80000000 | 16, 17 },
        }}),
        // Slot 'jobFinished'
        QtMocHelpers::SlotData<void(KTimerJob *, bool)>(18, 2, QMC::AccessPrivate, QMetaType::Void, {{
            { 0x80000000 | 16, 17 }, { QMetaType::Bool, 19 },
        }}),
        // Slot 'delayChanged'
        QtMocHelpers::SlotData<void()>(20, 2, QMC::AccessPrivate, QMetaType::Void),
    };
    QtMocHelpers::UintData qt_properties {
    };
    QtMocHelpers::UintData qt_enums {
    };
    return QtMocHelpers::metaObjectData<KTimerPref, qt_meta_tag_ZN10KTimerPrefE_t>(QMC::MetaObjectFlag{}, qt_stringData,
            qt_methods, qt_properties, qt_enums);
}
Q_CONSTINIT const QMetaObject KTimerPref::staticMetaObject = { {
    QMetaObject::SuperData::link<QDialog::staticMetaObject>(),
    qt_staticMetaObjectStaticContent<qt_meta_tag_ZN10KTimerPrefE_t>.stringdata,
    qt_staticMetaObjectStaticContent<qt_meta_tag_ZN10KTimerPrefE_t>.data,
    qt_static_metacall,
    nullptr,
    qt_staticMetaObjectRelocatingContent<qt_meta_tag_ZN10KTimerPrefE_t>.metaTypes,
    nullptr
} };

void KTimerPref::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    auto *_t = static_cast<KTimerPref *>(_o);
    if (_c == QMetaObject::InvokeMetaMethod) {
        switch (_id) {
        case 0: _t->exit(); break;
        case 1: _t->done((*reinterpret_cast<std::add_pointer_t<int>>(_a[1]))); break;
        case 2: _t->add(); break;
        case 3: _t->remove(); break;
        case 4: _t->help(); break;
        case 5: _t->currentChanged((*reinterpret_cast<std::add_pointer_t<QTreeWidgetItem*>>(_a[1])),(*reinterpret_cast<std::add_pointer_t<QTreeWidgetItem*>>(_a[2]))); break;
        case 6: _t->saveJobs((*reinterpret_cast<std::add_pointer_t<KConfig*>>(_a[1]))); break;
        case 7: _t->loadJobs((*reinterpret_cast<std::add_pointer_t<KConfig*>>(_a[1]))); break;
        case 8: _t->saveAllJobs(); break;
        case 9: _t->jobChanged((*reinterpret_cast<std::add_pointer_t<KTimerJob*>>(_a[1]))); break;
        case 10: _t->jobFinished((*reinterpret_cast<std::add_pointer_t<KTimerJob*>>(_a[1])),(*reinterpret_cast<std::add_pointer_t<bool>>(_a[2]))); break;
        case 11: _t->delayChanged(); break;
        default: ;
        }
    }
    if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        switch (_id) {
        default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
        case 9:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 0:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< KTimerJob* >(); break;
            }
            break;
        case 10:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 0:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< KTimerJob* >(); break;
            }
            break;
        }
    }
}

const QMetaObject *KTimerPref::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *KTimerPref::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_staticMetaObjectStaticContent<qt_meta_tag_ZN10KTimerPrefE_t>.strings))
        return static_cast<void*>(this);
    if (!strcmp(_clname, "Ui::PrefWidget"))
        return static_cast< Ui::PrefWidget*>(this);
    return QDialog::qt_metacast(_clname);
}

int KTimerPref::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QDialog::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 12)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 12;
    }
    if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 12)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 12;
    }
    return _id;
}
QT_WARNING_POP
