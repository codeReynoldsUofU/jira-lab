# Additional clean files
cmake_minimum_required(VERSION 3.16)

if("${CONFIG}" STREQUAL "" OR "${CONFIG}" STREQUAL "Debug")
  file(REMOVE_RECURSE
  "CMakeFiles/ktimer_autogen.dir/AutogenUsed.txt"
  "CMakeFiles/ktimer_autogen.dir/ParseCache.txt"
  "ktimer_autogen"
  )
endif()
