# CMake generated Testfile for 
# Source directory: /home/zreynolds/kde/src/ktimer/doc
# Build directory: /home/zreynolds/kde/src/ktimer/build-dev/doc
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
