/********************************************************************************
** Form generated from reading UI file 'prefwidget.ui'
**
** Created by: Qt User Interface Compiler version 6.11.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_PREFWIDGET_H
#define UI_PREFWIDGET_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QDialog>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLCDNumber>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSlider>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QSpinBox>
#include <QtWidgets/QToolButton>
#include <QtWidgets/QTreeWidget>
#include <klocalizedstring.h>
#include <kseparator.h>
#include "kurlrequester.h"

QT_BEGIN_NAMESPACE

class Ui_PrefWidget
{
public:
    QGridLayout *gridLayout;
    QPushButton *m_help;
    QPushButton *m_remove;
    QSpacerItem *spacerItem;
    QGroupBox *m_state;
    QGridLayout *gridLayout1;
    QSlider *m_slider;
    QLCDNumber *m_counter;
    QToolButton *m_pause;
    QToolButton *m_start;
    QToolButton *m_stop;
    QPushButton *m_add;
    QGroupBox *m_settings;
    QGridLayout *gridLayout2;
    QCheckBox *m_loop;
    QLabel *TextLabel2;
    QSpinBox *m_delay;
    QCheckBox *m_one;
    QCheckBox *m_consecutive;
    QLabel *TextLabel3;
    QLabel *TextLabel1;
    QSpinBox *m_delayH;
    QSpinBox *m_delayM;
    QLabel *TextLabel4;
    QLabel *TextLabel5;
    QSpacerItem *spacerItem1;
    KUrlRequester *m_commandLine;
    QTreeWidget *m_list;

    void setupUi(QDialog *PrefWidget)
    {
        if (PrefWidget->objectName().isEmpty())
            PrefWidget->setObjectName("PrefWidget");
        PrefWidget->resize(685, 352);
        gridLayout = new QGridLayout(PrefWidget);
#ifndef UI_Q_OS_MAC
        gridLayout->setSpacing(6);
#endif
        gridLayout->setContentsMargins(11, 11, 11, 11);
        gridLayout->setObjectName("gridLayout");
        m_help = new QPushButton(PrefWidget);
        m_help->setObjectName("m_help");

        gridLayout->addWidget(m_help, 2, 2, 1, 1);

        m_remove = new QPushButton(PrefWidget);
        m_remove->setObjectName("m_remove");

        gridLayout->addWidget(m_remove, 1, 2, 1, 1);

        spacerItem = new QSpacerItem(20, 20, QSizePolicy::Policy::Minimum, QSizePolicy::Policy::Expanding);

        gridLayout->addItem(spacerItem, 3, 2, 1, 1);

        m_state = new QGroupBox(PrefWidget);
        m_state->setObjectName("m_state");
        m_state->setEnabled(false);
        gridLayout1 = new QGridLayout(m_state);
#ifndef UI_Q_OS_MAC
        gridLayout1->setSpacing(6);
#endif
        gridLayout1->setContentsMargins(11, 11, 11, 11);
        gridLayout1->setObjectName("gridLayout1");
        m_slider = new QSlider(m_state);
        m_slider->setObjectName("m_slider");
        m_slider->setOrientation(Qt::Orientation::Horizontal);

        gridLayout1->addWidget(m_slider, 2, 0, 1, 3);

        m_counter = new QLCDNumber(m_state);
        m_counter->setObjectName("m_counter");
        m_counter->setDigitCount(6);

        gridLayout1->addWidget(m_counter, 1, 0, 1, 3);

        m_pause = new QToolButton(m_state);
        m_pause->setObjectName("m_pause");

        gridLayout1->addWidget(m_pause, 0, 1, 1, 1);

        m_start = new QToolButton(m_state);
        m_start->setObjectName("m_start");

        gridLayout1->addWidget(m_start, 0, 0, 1, 1);

        m_stop = new QToolButton(m_state);
        m_stop->setObjectName("m_stop");

        gridLayout1->addWidget(m_stop, 0, 2, 1, 1);


        gridLayout->addWidget(m_state, 5, 2, 1, 1);

        m_add = new QPushButton(PrefWidget);
        m_add->setObjectName("m_add");

        gridLayout->addWidget(m_add, 0, 2, 1, 1);

        m_settings = new QGroupBox(PrefWidget);
        m_settings->setObjectName("m_settings");
        m_settings->setEnabled(false);
        gridLayout2 = new QGridLayout(m_settings);
#ifndef UI_Q_OS_MAC
        gridLayout2->setSpacing(6);
#endif
        gridLayout2->setContentsMargins(11, 11, 11, 11);
        gridLayout2->setObjectName("gridLayout2");
        m_loop = new QCheckBox(m_settings);
        m_loop->setObjectName("m_loop");

        gridLayout2->addWidget(m_loop, 3, 0, 1, 8);

        TextLabel2 = new QLabel(m_settings);
        TextLabel2->setObjectName("TextLabel2");

        gridLayout2->addWidget(TextLabel2, 1, 0, 1, 1);

        m_delay = new QSpinBox(m_settings);
        m_delay->setObjectName("m_delay");
        m_delay->setMaximum(59);

        gridLayout2->addWidget(m_delay, 1, 5, 1, 2);

        m_one = new QCheckBox(m_settings);
        m_one->setObjectName("m_one");

        gridLayout2->addWidget(m_one, 4, 0, 1, 8);

        m_consecutive = new QCheckBox(m_settings);
        m_consecutive->setObjectName("m_consecutive");

        gridLayout2->addWidget(m_consecutive, 5, 0, 1, 8);

        TextLabel3 = new QLabel(m_settings);
        TextLabel3->setObjectName("TextLabel3");

        gridLayout2->addWidget(TextLabel3, 1, 7, 1, 1);

        TextLabel1 = new QLabel(m_settings);
        TextLabel1->setObjectName("TextLabel1");
        QSizePolicy sizePolicy(QSizePolicy::Policy::Maximum, QSizePolicy::Policy::Preferred);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(TextLabel1->sizePolicy().hasHeightForWidth());
        TextLabel1->setSizePolicy(sizePolicy);
        TextLabel1->setAutoFillBackground(false);

        gridLayout2->addWidget(TextLabel1, 0, 0, 1, 3);

        m_delayH = new QSpinBox(m_settings);
        m_delayH->setObjectName("m_delayH");

        gridLayout2->addWidget(m_delayH, 1, 1, 1, 1);

        m_delayM = new QSpinBox(m_settings);
        m_delayM->setObjectName("m_delayM");
        m_delayM->setMaximum(59);

        gridLayout2->addWidget(m_delayM, 1, 3, 1, 1);

        TextLabel4 = new QLabel(m_settings);
        TextLabel4->setObjectName("TextLabel4");

        gridLayout2->addWidget(TextLabel4, 1, 2, 1, 1);

        TextLabel5 = new QLabel(m_settings);
        TextLabel5->setObjectName("TextLabel5");

        gridLayout2->addWidget(TextLabel5, 1, 4, 1, 1);

        spacerItem1 = new QSpacerItem(20, 20, QSizePolicy::Policy::Expanding, QSizePolicy::Policy::Minimum);

        gridLayout2->addItem(spacerItem1, 1, 8, 1, 1);

        m_commandLine = new KUrlRequester(m_settings);
        m_commandLine->setObjectName("m_commandLine");
        QSizePolicy sizePolicy1(QSizePolicy::Policy::Preferred, QSizePolicy::Policy::Preferred);
        sizePolicy1.setHorizontalStretch(1);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(m_commandLine->sizePolicy().hasHeightForWidth());
        m_commandLine->setSizePolicy(sizePolicy1);
        m_commandLine->setSizeIncrement(QSize(1, 0));
        m_commandLine->setAutoFillBackground(true);

        gridLayout2->addWidget(m_commandLine, 0, 3, 1, 6);


        gridLayout->addWidget(m_settings, 5, 0, 1, 1);

        m_list = new QTreeWidget(PrefWidget);
        m_list->setObjectName("m_list");
        m_list->setAllColumnsShowFocus(true);

        gridLayout->addWidget(m_list, 0, 0, 4, 2);

        QWidget::setTabOrder(m_add, m_remove);
        QWidget::setTabOrder(m_remove, m_commandLine);
        QWidget::setTabOrder(m_commandLine, m_delayH);
        QWidget::setTabOrder(m_delayH, m_delayM);
        QWidget::setTabOrder(m_delayM, m_delay);
        QWidget::setTabOrder(m_delay, m_loop);
        QWidget::setTabOrder(m_loop, m_one);
        QWidget::setTabOrder(m_one, m_start);
        QWidget::setTabOrder(m_start, m_pause);
        QWidget::setTabOrder(m_pause, m_stop);
        QWidget::setTabOrder(m_stop, m_slider);
        QWidget::setTabOrder(m_slider, m_help);

        retranslateUi(PrefWidget);

        QMetaObject::connectSlotsByName(PrefWidget);
    } // setupUi

    void retranslateUi(QDialog *PrefWidget)
    {
        PrefWidget->setWindowTitle(tr2i18n("Timer Settings", nullptr));
#if QT_CONFIG(tooltip)
        m_help->setToolTip(tr2i18n("Detailed help documentation", nullptr));
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(whatsthis)
        m_help->setWhatsThis(tr2i18n("Click here to open the help documentation viewer.", nullptr));
#endif // QT_CONFIG(whatsthis)
#if QT_CONFIG(tooltip)
        m_remove->setToolTip(tr2i18n("Remove a task", nullptr));
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(whatsthis)
        m_remove->setWhatsThis(tr2i18n("Remove a task from the list.", nullptr));
#endif // QT_CONFIG(whatsthis)
        m_remove->setText(tr2i18n("&Remove", nullptr));
        m_state->setTitle(tr2i18n("State", nullptr));
#if QT_CONFIG(tooltip)
        m_slider->setToolTip(tr2i18n("Speed up or slow down your countdown", nullptr));
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(whatsthis)
        m_slider->setWhatsThis(tr2i18n("You can use this slider to adjust the time.", nullptr));
#endif // QT_CONFIG(whatsthis)
#if QT_CONFIG(tooltip)
        m_counter->setToolTip(tr2i18n("Time in seconds until command is executed", nullptr));
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(whatsthis)
        m_counter->setWhatsThis(tr2i18n("This number is how many seconds are left for the selected countdown.", nullptr));
#endif // QT_CONFIG(whatsthis)
#if QT_CONFIG(tooltip)
        m_pause->setToolTip(tr2i18n("Pause a countdown", nullptr));
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(whatsthis)
        m_pause->setWhatsThis(tr2i18n("Use this to pause a timer countdown.", nullptr));
#endif // QT_CONFIG(whatsthis)
        m_pause->setText(tr2i18n("||", nullptr));
#if QT_CONFIG(tooltip)
        m_start->setToolTip(tr2i18n("Start a countdown", nullptr));
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(whatsthis)
        m_start->setWhatsThis(tr2i18n("Use this to start or restart a countdown.", nullptr));
#endif // QT_CONFIG(whatsthis)
        m_start->setText(tr2i18n(">", nullptr));
#if QT_CONFIG(tooltip)
        m_stop->setToolTip(tr2i18n("Stop a countdown", nullptr));
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(whatsthis)
        m_stop->setWhatsThis(tr2i18n("Use this to stop the countdown for a task.", nullptr));
#endif // QT_CONFIG(whatsthis)
        m_stop->setText(tr2i18n("=", nullptr));
#if QT_CONFIG(tooltip)
        m_add->setToolTip(tr2i18n("Add a new task", nullptr));
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(whatsthis)
        m_add->setWhatsThis(tr2i18n("Add a new task to the list.", nullptr));
#endif // QT_CONFIG(whatsthis)
        m_add->setText(tr2i18n("&New", nullptr));
        m_settings->setTitle(tr2i18n("Settings", nullptr));
#if QT_CONFIG(tooltip)
        m_loop->setToolTip(tr2i18n("Check this box if you want your countdown to start over after it finishes", nullptr));
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(whatsthis)
        m_loop->setWhatsThis(tr2i18n("Check this box if you want your countdown to start over after it finishes", nullptr));
#endif // QT_CONFIG(whatsthis)
        m_loop->setText(tr2i18n("&Loop", nullptr));
        TextLabel2->setText(tr2i18n("Delay:", nullptr));
#if QT_CONFIG(tooltip)
        m_delay->setToolTip(tr2i18n("Enter the seconds here", nullptr));
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(whatsthis)
        m_delay->setWhatsThis(tr2i18n("You can change the amount of time in the countdown here.", nullptr));
#endif // QT_CONFIG(whatsthis)
#if QT_CONFIG(tooltip)
        m_one->setToolTip(tr2i18n("Check this box if you only want to open one copy of your program", nullptr));
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(whatsthis)
        m_one->setWhatsThis(tr2i18n("Check this box if you only want one instance to open", nullptr));
#endif // QT_CONFIG(whatsthis)
        m_one->setText(tr2i18n("Start only &one instance", nullptr));
#if QT_CONFIG(tooltip)
        m_consecutive->setToolTip(tr2i18n("Check this box if you want to execute this task after the previous one finishes", nullptr));
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(whatsthis)
        m_consecutive->setWhatsThis(tr2i18n("Check this box if you want to execute this task after the previous one finishes", nullptr));
#endif // QT_CONFIG(whatsthis)
        m_consecutive->setText(tr2i18n("Consecutive task", nullptr));
        TextLabel3->setText(tr2i18n("seconds", nullptr));
        TextLabel1->setText(tr2i18n("Command line:", nullptr));
#if QT_CONFIG(tooltip)
        m_delayH->setToolTip(tr2i18n("Enter the hours here", nullptr));
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(tooltip)
        m_delayM->setToolTip(tr2i18n("Enter the minutes here", nullptr));
#endif // QT_CONFIG(tooltip)
        TextLabel4->setText(tr2i18n("hours", nullptr));
        TextLabel5->setText(tr2i18n("minutes", nullptr));
#if QT_CONFIG(tooltip)
        m_commandLine->setToolTip(tr2i18n("command you would like to run when time is up", nullptr));
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(whatsthis)
        m_commandLine->setWhatsThis(tr2i18n("Enter a program you would like to run when the countdown is zero", nullptr));
#endif // QT_CONFIG(whatsthis)
        QTreeWidgetItem *___qtreewidgetitem = m_list->headerItem();
        ___qtreewidgetitem->setText(4, tr2i18n("Last Run", nullptr));
        ___qtreewidgetitem->setText(3, tr2i18n("Command", nullptr));
        ___qtreewidgetitem->setText(2, tr2i18n("State", nullptr));
        ___qtreewidgetitem->setText(1, tr2i18n("Delay", nullptr));
        ___qtreewidgetitem->setText(0, tr2i18n("Counter", nullptr));
#if QT_CONFIG(tooltip)
        m_list->setToolTip(tr2i18n("List of countdowns you have set", nullptr));
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(whatsthis)
        m_list->setWhatsThis(tr2i18n("New countdowns are put here. You can add and remove them, and stop and start them.", nullptr));
#endif // QT_CONFIG(whatsthis)
    } // retranslateUi

};

namespace Ui {
    class PrefWidget: public Ui_PrefWidget {};
} // namespace Ui

QT_END_NAMESPACE

#endif // PREFWIDGET_H

